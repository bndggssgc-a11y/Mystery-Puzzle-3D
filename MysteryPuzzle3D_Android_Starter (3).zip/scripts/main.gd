extends Control

const SAVE_PATH = "user://mystery_save.json"
const ADMIN_PIN = "2468"

var level := 1
var xp := 0
var screen: String = "lobby"
var current_answer := ""
var puzzle_index := 0
var puzzles: Array = [
    {"q":"আমি যত বেশি শুকাই, তত বেশি ভিজি। আমি কে?","a":"তোয়ালে","hint":"গোসলের পরে কাজে লাগে"},
    {"q":"দাঁত আছে, কিন্তু কামড়াতে পারে না। কী সেটা?","a":"চিরুনি","hint":"চুল আঁচড়াতে ব্যবহার হয়"},
    {"q":"যতই নাও, ততই বড় হয়। কী সেটা?","a":"গর্ত","hint":"মাটিতে তৈরি হয়"}
]
var root_box: VBoxContainer

func _ready():
    _load_data()
    _show_lobby()

func _clear():
    for child in get_children():
        child.queue_free()
    var bg = ColorRect.new()
    bg.color = Color("#101a2b")
    bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(bg)
    root_box = VBoxContainer.new()
    root_box.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    root_box.add_theme_constant_override("separation", 22)
    root_box.add_theme_color_override("font_color", Color.WHITE)
    root_box.add_theme_font_size_override("font_size", 25)
    root_box.add_theme_constant_override("margin_left", 28)
    root_box.add_theme_constant_override("margin_right", 28)
    root_box.add_theme_constant_override("margin_top", 55)
    root_box.add_theme_constant_override("margin_bottom", 35)
    add_child(root_box)

func _label(txt: String, size := 24):
    var l = Label.new()
    l.text = txt
    l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    l.add_theme_font_size_override("font_size", size)
    root_box.add_child(l)
    return l

func _button(txt: String, callback: Callable):
    var b = Button.new()
    b.text = txt
    b.custom_minimum_size = Vector2(0, 68)
    b.add_theme_font_size_override("font_size", 23)
    b.pressed.connect(callback)
    root_box.add_child(b)
    return b

func _show_lobby():
    screen = "lobby"
    _clear()
    _label("MYSTERY PUZZLE 3D", 34)
    _label("রহস্যের জগতে স্বাগতম")
    _label("LEVEL  %d     XP  %d" % [level, xp], 22)
    _button("▶  MATCH START", _start_match)
    _button("🧩  ধাঁধার সংগ্রহ", _show_collection)
    _button("⚙  ADMIN PANEL", _ask_admin)
    _label("ম্যাচ শুরু করে ধাঁধা সমাধান করো।")

func _start_match():
    screen = "puzzle"
    puzzle_index = (level - 1) % puzzles.size()
    var p = puzzles[puzzle_index]
    _clear()
    _label("MYSTERY ROOM  •  LEVEL %d" % level, 28)
    _label("🗝️  রহস্য কক্ষ", 32)
    _label(p["q"], 27)
    var answer = LineEdit.new()
    answer.placeholder_text = "উত্তর লিখুন..."
    answer.custom_minimum_size = Vector2(0, 65)
    answer.add_theme_font_size_override("font_size", 24)
    root_box.add_child(answer)
    _button("উত্তর জমা দিন", func(): _check_answer(answer.text))
    _button("ইঙ্গিত দেখুন", func(): _show_hint())
    _button("লবিতে ফিরুন", _show_lobby)

func _check_answer(value: String):
    var expected = str(puzzles[puzzle_index]["a"]).strip_edges()
    if value.strip_edges().to_lower() == expected.to_lower():
        xp += 100
        if xp >= level * 150:
            xp -= level * 150
            level += 1
        _save_data()
        _clear()
        _label("🎉 সঠিক উত্তর!", 34)
        _label("+100 XP")
        _label("নতুন রহস্যের দরজা খুলে গেছে।")
        _button("পরের লেভেল", _start_match)
        _button("লবিতে ফিরুন", _show_lobby)
    else:
        _label("উত্তরটি সঠিক হয়নি। আবার চেষ্টা করো!", 20)

func _show_hint():
    _label("ইঙ্গিত: " + str(puzzles[puzzle_index]["hint"]), 20)

func _show_collection():
    _clear()
    _label("ধাঁধার সংগ্রহ", 32)
    for i in range(puzzles.size()):
        _label("ধাঁধা %d: %s" % [i + 1, puzzles[i]["q"]], 18)
    _button("ফিরে যান", _show_lobby)

func _ask_admin():
    _clear()
    _label("ADMIN LOGIN", 32)
    _label("অ্যাডমিন PIN লিখুন")
    var pin = LineEdit.new()
    pin.placeholder_text = "PIN"
    pin.secret = true
    pin.custom_minimum_size = Vector2(0, 65)
    root_box.add_child(pin)
    _button("প্রবেশ করুন", func():
        if pin.text == ADMIN_PIN:
            _show_admin()
        else:
            _label("ভুল PIN। আবার চেষ্টা করুন।", 18)
    )
    _button("ফিরে যান", _show_lobby)

func _show_admin():
    screen = "admin"
    _clear()
    _label("ADMIN CONTROL PANEL", 30)
    _label("Level: %d   XP: %d" % [level, xp], 20)
    _button("নতুন ধাঁধা যোগ করুন", _add_puzzle)
    _button("XP রিসেট করুন", func():
        xp = 0
        _save_data()
        _show_admin()
    )
    _button("Level রিসেট করুন", func():
        level = 1
        xp = 0
        _save_data()
        _show_admin()
    )
    _button("ডেটা সেভ করুন", func():
        _save_data()
        _label("ডেটা সেভ হয়েছে।", 18)
    )
    _button("লবিতে ফিরুন", _show_lobby)
    _label("প্রাথমিক PIN: 2468 — প্রকাশের আগে বদলে নিন", 15)

func _add_puzzle():
    _clear()
    _label("নতুন ধাঁধা যোগ করুন", 28)
    var question = LineEdit.new()
    question.placeholder_text = "ধাঁধার প্রশ্ন"
    question.custom_minimum_size = Vector2(0, 60)
    root_box.add_child(question)
    var answer = LineEdit.new()
    answer.placeholder_text = "সঠিক উত্তর"
    answer.custom_minimum_size = Vector2(0, 60)
    root_box.add_child(answer)
    var hint = LineEdit.new()
    hint.placeholder_text = "ইঙ্গিত"
    hint.custom_minimum_size = Vector2(0, 60)
    root_box.add_child(hint)
    _button("যোগ করুন", func():
        if question.text.strip_edges() != "" and answer.text.strip_edges() != "":
            puzzles.append({"q": question.text, "a": answer.text, "hint": hint.text})
            _save_data()
            _show_admin()
        else:
            _label("প্রশ্ন ও উত্তর দিতে হবে।", 18)
    )
    _button("ফিরে যান", _show_admin)

func _save_data():
    var data = {"level": level, "xp": xp, "puzzles": puzzles}
    var f = FileAccess.open(SAVE_PATH, FileAccess.WRITE)
    if f:
        f.store_string(JSON.stringify(data))

func _load_data():
    if not FileAccess.file_exists(SAVE_PATH):
        return
    var f = FileAccess.open(SAVE_PATH, FileAccess.READ)
    if not f:
        return
    var parsed = JSON.parse_string(f.get_as_text())
    if typeof(parsed) == TYPE_DICTIONARY:
        level = int(parsed.get("level", 1))
        xp = int(parsed.get("xp", 0))
        if parsed.has("puzzles") and typeof(parsed["puzzles"]) == TYPE_ARRAY:
            puzzles = parsed["puzzles"]

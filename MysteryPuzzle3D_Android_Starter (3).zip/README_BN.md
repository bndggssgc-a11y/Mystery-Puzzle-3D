# Mystery Puzzle 3D — Starter Project

এটি Godot 4-এর Android-এ এক্সপোর্ট করার উপযোগী একটি প্রাথমিক playable prototype। এতে lobby, level/XP, বাংলা ধাঁধা, hint, local save এবং PIN-সুরক্ষিত in-game admin panel আছে।

## চালানোর নিয়ম
1. PC-তে Godot Engine 4.3 বা নতুন সংস্করণ ইনস্টল করুন।
2. Godot-এ `project.godot` ফাইলটি Import করুন।
3. Play চাপুন।

## Android APK বানানো
1. Godot Editor-এর Editor > Manage Export Templates থেকে matching export templates ইনস্টল করুন।
2. Android export setup-এ Android SDK/JDK configure করুন।
3. Project > Export-এ Android preset যোগ করুন।
4. APK export করুন।

## গুরুত্বপূর্ণ সীমাবদ্ধতা
- এটি প্রথম prototype; এখনো পূর্ণ 3D পরিবেশ/চরিত্র/অ্যানিমেশন যোগ করা হয়নি। বর্তমান গেমপ্লে UI-ভিত্তিক puzzle prototype।
- Admin panel বর্তমানে একই ডিভাইসের local data নিয়ন্ত্রণ করে। অনলাইন/দূর থেকে নিয়ন্ত্রণ, player accounts, cloud sync বা server-side moderation নেই।
- PIN `scripts/main.gd`-এ `ADMIN_PIN` হিসেবে আছে; প্রকাশের আগে পরিবর্তন করুন। বাস্তব multiplayer/production ব্যবহারে client-side PIN নিরাপদ নয়।
- গেমের ডেটা Android app-এর user:// storage-এ থাকে।
